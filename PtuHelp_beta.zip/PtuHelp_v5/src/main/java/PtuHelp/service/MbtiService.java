package PtuHelp.service;

public interface MbtiService {
	void saveTestResult(Integer userId, String result);
}
