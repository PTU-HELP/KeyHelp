package PtuHelp.service;

import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.core.sync.RequestBody;

import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;
import org.springframework.web.multipart.MultipartFile;

public class S3Uploader {
    private final S3Client s3;
    private final String bucketName = "keyboardimage";  // S3 버킷 이름 지정

    public S3Uploader() {
        // AWS 자격 증명 설정
        this.s3 = S3Client.builder()
                .region(Region.AP_NORTHEAST_2) // 서울 리전 예시
                .credentialsProvider(StaticCredentialsProvider.create(
                        AwsBasicCredentials.create("AKIA4WJPWQBS7IZVRLWD", "oM0z9cppcROwwG8oK3eu3tFD9X3cC3w/WV9qPaHf")))  // 자격 증명 입력
                .build();
    }

    public String uploadFile(MultipartFile file, String key) throws IOException {
        // 임시 파일 생성 후 MultipartFile을 저장
        Path tempFile = Files.createTempFile("upload-", file.getOriginalFilename());
        file.transferTo(tempFile.toFile());

        // S3 업로드 요청 생성
        PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                .bucket(bucketName)
                .key(key) // 예: 'images/filename.png' 형식으로 폴더 구분
                .build();

        // 파일을 S3에 업로드
        s3.putObject(putObjectRequest, RequestBody.fromFile(tempFile));

        // 업로드된 파일의 URL 반환
        return s3.utilities().getUrl(builder -> builder.bucket(bucketName).key(key)).toString();
    }
}
