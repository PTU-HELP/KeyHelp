
document.addEventListener("DOMContentLoaded", function () {
    console.log("MBTI result page loaded");
    // Add any JavaScript logic if needed to handle dynamic content
});
