package PtuHelp.controller;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;

import PtuHelp.service.UserService;
import PtuHelp.model.User;

@Controller
public class EmailController {

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private UserService userService;

    @PostMapping("/auth/register-email")
    public String registerUser(User user) {
        // 이메일 중복 체크
        if (userService.findUserByUsername(user.getName()) != null) {
            return "redirect:/auth/register?error=emailExists"; // 이름이 이미 사용 중인 경우
        }

        // 사용자 등록
        userService.registerUser(user);

        // 이메일 인증 링크 생성 및 발송
        String token = userService.generateVerificationToken(user.getEmail());
        String verificationLink = "http://localhost:8080/PtuHelp/verify?token=" + token;

        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, "utf-8");
            helper.setTo(user.getEmail());
            helper.setSubject("이메일 인증");
            helper.setText("<p>이메일 인증 링크: <a href='" + verificationLink + "'>여기를 클릭하세요</a></p>", true); // HTML 포맷 사용
            mailSender.send(mimeMessage);
        } catch (MessagingException e) {
            e.printStackTrace();
            return "error"; // 오류 발생 시 오류 페이지로 이동
        }

        return "registerSuccess"; // 회원가입 성공 페이지
    }

    @GetMapping("/verify")
    public String verifyEmail(@RequestParam("token") String token) {
        boolean isVerified = userService.verifyEmail(token);
        if (isVerified) {
            return "emailVerified"; // 인증 성공 페이지
        } else {
            return "emailVerificationFailed"; // 인증 실패 페이지
        }
    }
}

