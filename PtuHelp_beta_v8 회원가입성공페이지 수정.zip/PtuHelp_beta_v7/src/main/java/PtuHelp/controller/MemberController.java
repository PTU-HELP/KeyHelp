package PtuHelp.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import PtuHelp.model.User;
import PtuHelp.service.UserService;

@Controller
public class MemberController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/auth/register")
	public String showRegisterPage() {
		return "join";
	}
	
	@PostMapping("/auth/register")
    public String register(User user, Model model) {
        try {
        	// 이메일 중복 체크
            if (userService.getUserByEmail(user.getEmail()) != null) {
                model.addAttribute("error", "이미 등록된 이메일입니다."); // 에러 메시지 추가
                return "join"; // 회원가입 페이지로 다시 이동
            }

            // 사용자 등록 및 이메일 인증 링크 발송
            userService.registerUser(user);
            model.addAttribute("message", "회원가입이 완료되었습니다. 이메일을 확인하여 인증을 완료해 주세요.");
            return "registerSuccess";  // 회원가입 성공 페이지로 이동
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "join";  // 회원가입 페이지로 다시 이동
        } catch (Exception e) {
        	e.printStackTrace();
            model.addAttribute("error", "예기치 않은 오류가 발생했습니다. 다시 시도해 주세요.");
            return "join";  // 오류 발생 시 회원가입 페이지로 다시 이동
        }
    }
	
	@GetMapping("/auth/login")
	public String showLoginPage() {
	    return "login";
	}

	@PostMapping("/auth/login")
	public String login(@RequestParam("name") String name,
	                    @RequestParam("pw") String pw,
	                    HttpSession session, Model model) {
	    User user = userService.getUserByNameAndPassword(name, pw);
	    if (user != null) {
	        // 이메일 인증 확인
	        if (!user.isEmailVerified()) {
	            model.addAttribute("error", "이메일 인증이 필요합니다.");
	            return "login";  // 로그인 페이지로 다시 이동
	        }

	        // 이메일 인증이 완료된 경우 세션 설정
	        session.setAttribute("username", user.getName());
	        session.setAttribute("userId", user.getId());
	        session.setAttribute("isAdmin", user.isAdminUser());
	        return "redirect:/";  // 메인 페이지로 리다이렉트
	    } else {
	        model.addAttribute("error", "잘못된 이름 또는 비밀번호입니다.");
	        return "login";  // 로그인 페이지로 다시 이동
	    }
	}

	@GetMapping("/auth/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}
