package PtuHelp.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import PtuHelp.model.Keyboard;
import PtuHelp.service.KeyboardService;
import PtuHelp.service.UserService;

@Controller
public class SurveyController {

    @Autowired
    private KeyboardService keyboardService;
    @Autowired
    private UserService userService; // UserService 추가

    @GetMapping("/survey")
    public String showSurveyPage(HttpSession session, Model model) {
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) {
            model.addAttribute("error", "설문을 진행하려면 로그인해주세요.");
            return "redirect:/auth/login";
        }
        
        // 이메일 인증 여부 확인
        if (!userService.isEmailVerified(userId)) {
            model.addAttribute("error", "이메일 인증이 필요합니다.");
            return "redirect:/auth/login"; // 이메일 인증이 필요할 경우 로그인 페이지로 리다이렉트
        }
        
        return "survey"; // 설문 페이지
    }

    @PostMapping("/survey/submit")
    public String submitSurvey(
        @RequestParam String connectionType,
        @RequestParam String usage,
        @RequestParam String switchType,
        @RequestParam String size,
        @RequestParam String color,
        @RequestParam String priceRange,
        HttpSession session, Model model) {

        if (session.getAttribute("userId") == null) {
            model.addAttribute("error", "설문을 진행하려면 로그인해주세요.");
            return "redirect:/auth/login";
        }

        // 설문 점수 계산
        int totalScore = calculateScore(connectionType, usage, switchType, size, color, priceRange);

        // 추천 키보드 조회
        List<Keyboard> keyboards = keyboardService.getKeyboardsByTotalScore(totalScore);
        model.addAttribute("keyboards", keyboards);
        return "result"; // 설문 결과 페이지
    }

    private int calculateScore(String connectionType, String usage, String switchType, String size, String color, String priceRange) {
        int score = 0;
        // 점수 계산 로직
        score += connectionType.equals("유선") ? 100000 : 200000;
        score += usage.equals("게이밍") ? 10000 : usage.equals("사무용") ? 20000 : 30000;
        score += switchType.equals("청축") ? 1000 : switchType.equals("갈축") ? 2000 : 3000;
        score += size.equals("풀사이즈") ? 100 : size.equals("텐키리스") ? 200 : 300;
        score += color.equals("블랙") ? 10 : color.equals("화이트") ? 20 : 30;
        score += priceRange.equals("0-10") ? 1 : priceRange.equals("10-20") ? 2 : 3;
        return score;
    }
}
