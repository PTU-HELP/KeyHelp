package PtuHelp.dao;

import PtuHelp.model.User;

public interface UserDao {
    void insertUser(User user);
    User getUserByUsername(String username);
    void saveVerificationToken(String email, String token); // 토큰 저장
    User getUserByVerificationToken(String token); // 토큰으로 사용자 조회
    void verifyUserEmail(String email); // 이메일 인증 상태 업데이트
    User getUserByEmail(String email);
    User getUserById(int userId);
    void deleteVerificationTokenByEmail(String email);
    User getVerificationTokenByEmail(String email);
    String getEmailByToken(String token);
}
