package PtuHelp.dao;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import PtuHelp.model.User;

@Repository
public class UserDaoImpl implements UserDao {
    
    @Autowired
    private SqlSession sqlSession;
    
    private static final String namespace = "PtuHelp.mapper.MemberMapper";
    
    @Override
    public User getUserByUsername(String username) {
        return sqlSession.selectOne(namespace + ".getUserByUsername", username);
    }

    @Override
    public void insertUser(User user) {
        sqlSession.insert(namespace + ".insertUser", user);
    }

    @Override
    public void saveVerificationToken(String email, String token) {
        sqlSession.update(namespace + ".saveVerificationToken", Map.of("email", email, "token", token));
    }

    @Override
    public User getUserByVerificationToken(String token) {
        return sqlSession.selectOne(namespace + ".getUserByVerificationToken", token);
    }

    @Override
    public void verifyUserEmail(String email) {
        sqlSession.update(namespace + ".verifyUserEmail", email);
    }

    @Override
    public User getUserByEmail(String email) {
        return sqlSession.selectOne(namespace + ".getUserByEmail", email);
    }

    @Override
    public User getUserById(int userId) {
        return sqlSession.selectOne(namespace + ".getUserById", userId);
    }

    @Override
    public void deleteVerificationTokenByEmail(String email) {
        sqlSession.delete(namespace + ".deleteVerificationTokenByEmail", email);
    }

	@Override
	public User getVerificationTokenByEmail(String email) {
		return sqlSession.selectOne(namespace + ".getVerificationTokenByEmail", email);
	}

	@Override
	public String getEmailByToken(String token) {
		return sqlSession.selectOne(namespace + ".getEmailByToken", token);
	}
}
