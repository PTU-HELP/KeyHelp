package PtuHelp.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Keyboard {
    private int keyboardId;
    private String url;
    private String keyname;
    private int totalScore;  // 설문 점수 필드
    private double averageRating;  // 평균 평점 필드
    private int createdBy;
}
