package PtuHelp.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SurveyResult {
    private Integer userId; // 로그인한 사용자 고유 번호
    private Integer totalScore; // 설문 점수

    public SurveyResult() {
    }

    public SurveyResult(Integer userId, Integer totalScore) {
        this.userId = userId;
        this.totalScore = totalScore;
    }
}
