package PtuHelp.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VerificationToken {
    private String email; // 이메일
    private String token; // 인증 토큰

    public VerificationToken(String email, String token) {
        this.email = email;
        this.token = token;
    }
}
