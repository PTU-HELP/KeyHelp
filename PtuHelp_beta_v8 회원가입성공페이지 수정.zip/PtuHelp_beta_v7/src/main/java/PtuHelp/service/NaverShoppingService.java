package PtuHelp.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

@Service
public class NaverShoppingService {
    private static final String CLIENT_ID = "YOUR_CLIENT_ID";  // 네이버 애플리케이션의 Client ID
    private static final String CLIENT_SECRET = "YOUR_CLIENT_SECRET";  // 네이버 애플리케이션의 Client Secret

    public String getLowestPrice(String keyword) {
        try {
            // 검색어를 UTF-8로 인코딩
            String query = URLEncoder.encode(keyword, "UTF-8");
            String apiURL = "https://openapi.naver.com/v1/search/shop.json?query=" + query;

            // URL 연결 설정
            URL url = new URL(apiURL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("X-Naver-Client-Id", CLIENT_ID);
            conn.setRequestProperty("X-Naver-Client-Secret", CLIENT_SECRET);

            // 응답 코드 확인
            int responseCode = conn.getResponseCode();
            BufferedReader br;
            if (responseCode == 200) { // 성공
                br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            } else { // 에러
                br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            }

            // 응답 읽기
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                response.append(line);
            }
            br.close();

            // JSON 파싱
            JSONObject jsonObject = new JSONObject(response.toString());
            JSONArray items = jsonObject.getJSONArray("items");
            if (items.length() > 0) {
                JSONObject firstItem = items.getJSONObject(0);
                return firstItem.getString("lprice"); // 최저 가격 반환
            } else {
                return "가격 정보를 찾을 수 없습니다.";
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "오류가 발생했습니다.";
        }
    }
}
