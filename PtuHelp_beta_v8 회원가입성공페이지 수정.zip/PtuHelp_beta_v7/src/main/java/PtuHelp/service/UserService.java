package PtuHelp.service;

import PtuHelp.model.User;

public interface UserService {
	void registerUser(User user);
	User findUserByUsername(String name);
	User getUserByNameAndPassword(String name, String pw);
	String generateVerificationToken(String email);
    boolean verifyEmail(String token);
    // 이메일 발송 메서드 추가
    void sendVerificationEmail(String email, String token);
    boolean isEmailVerified(int userId);
    User getUserByEmail(String email); // 이메일로 사용자 조회
    User findUserByEmail(String email);
}
