package PtuHelp.service;

import java.util.UUID;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import PtuHelp.dao.UserDao;
import PtuHelp.model.User;

@Service("userService")
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;
    
    @Autowired
    private JavaMailSender mailSender;

    @Override
    public void registerUser(User user) {
        System.out.println("registerUser 메서드 호출됨");

        // 비밀번호 유효성 체크
        if (user.getPw() == null || user.getPw().isEmpty()) {
            throw new IllegalArgumentException("비밀번호는 비워둘 수 없습니다.");
        }

        // 이메일 중복 체크
        if (userDao.getUserByEmail(user.getEmail()) != null) {
            throw new IllegalArgumentException("이미 등록된 이메일입니다.");
        }

        // 이름 중복 체크
        if (userDao.getUserByUsername(user.getName()) != null) {
            throw new IllegalArgumentException("이미 사용 중인 이름입니다.");
        }

        // 비밀번호 암호화 후 저장
        user.setPw(passwordEncoder.encode(user.getPw()));  
        userDao.insertUser(user);
        
        // 이메일 인증 토큰이 이미 존재하는지 확인
        if (userDao.getVerificationTokenByEmail(user.getEmail()) == null) {
            String token = generateVerificationToken(user.getEmail());
            sendVerificationEmail(user.getEmail(), token); // 이메일 인증 메일 발송
        } else {
            System.out.println("이메일 인증 링크가 이미 발송되었습니다.");
        }
    }

    @Override
    public User findUserByUsername(String username) {
        return userDao.getUserByUsername(username);
    }

    @Override
    public User getUserByNameAndPassword(String name, String pw) {
        User user = userDao.getUserByUsername(name);
        if (user != null && passwordEncoder.matches(pw, user.getPw())) {
            return user;
        }
        return null;  // 사용자 인증 실패 시 null 반환
    }

    @Override
    public String generateVerificationToken(String email) {
        // 기존 토큰 삭제
        userDao.deleteVerificationTokenByEmail(email);
        
        String token = UUID.randomUUID().toString();  // 랜덤 토큰 생성
        userDao.saveVerificationToken(email, token);  // 데이터베이스에 토큰 저장
        return token;
    }

    @Override
    public boolean verifyEmail(String token) {
        String email = userDao.getEmailByToken(token); // 토큰으로 이메일 조회
        if (email != null) {
            userDao.verifyUserEmail(email); // 이메일 인증 완료 처리
            return true;
        }
        return false; // 이메일이 없으면 인증 실패
    }

    @Override
    public void sendVerificationEmail(String email, String token) {
        String verificationLink = "http://localhost:8080/PtuHelp/verify?token=" + token;

        // HTML 이메일 발송을 위해 MimeMessage 사용
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        try {
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, "utf-8");
            helper.setTo(email);
            helper.setSubject("이메일 인증");
            helper.setText("<p>이메일 인증 링크: <a href='" + verificationLink + "'>여기를 클릭하세요</a></p>", true); // HTML 포맷 사용
            mailSender.send(mimeMessage);
        } catch (MessagingException e) {
            e.printStackTrace(); // 예외 처리
            throw new RuntimeException("이메일 전송에 실패했습니다."); // 적절한 예외 처리
        }
    }

    @Override
    public boolean isEmailVerified(int userId) {
        User user = userDao.getUserById(userId); // 사용자 ID로 사용자 조회
        return user != null && user.isEmailVerified(); // 사용자 존재 여부 및 인증 상태 반환
    }

    @Override
    public User getUserByEmail(String email) {
        return userDao.getUserByEmail(email); // UserDao에서 이메일로 사용자 조회
    }

    @Override
    public User findUserByEmail(String email) {
        return userDao.getUserByEmail(email);
    }
}
