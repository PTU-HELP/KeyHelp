document.addEventListener("DOMContentLoaded", function () {
    console.log("설문 결과 페이지 로드됨");

    // 키보드 목록 컨테이너를 선택
    const keyboardContainer = document.getElementById("keyboardContainer");

    // 키보드 목록 컨테이너가 있는 경우에만 클릭 이벤트를 추가
    if (keyboardContainer) {
        // 컨테이너에 이벤트 위임을 통해 클릭 이벤트 추가
        keyboardContainer.addEventListener("click", function (event) {
            // 클릭된 요소에서 가장 가까운 `.keyboard-card` 요소를 찾아 저장
            const keyboardCard = event.target.closest(".keyboard-card");

            if (keyboardCard) {
                const keyboardId = keyboardCard.getAttribute("data-id");
                console.log("Keyboard ID:", keyboardId);

                // 키보드 ID가 유효한 경우에만 이동
                if (keyboardId && keyboardId !== "undefined" && keyboardId !== "0") {
                    location.href = `${window.contextPath}/keyboards/${keyboardId}`;
                } else {
                    console.error("유효하지 않은 Keyboard ID:", keyboardId);
                }
            }
        });
    }
});
