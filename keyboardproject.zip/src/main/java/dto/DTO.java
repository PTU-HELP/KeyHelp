package dto;

import dto.DTO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

	public class DTO {
	    private String jdbcURL = "jdbc:mysql://localhost:3306/your_database_name"; // Update your database URL
	    private String jdbcUsername = "your_username"; // Update your database username
	    private String jdbcPassword = "your_password"; // Update your database password

	    public DTO(String string, String string2, String string3) {
			// TODO Auto-generated constructor stub
		}

		// Method to add a new user
	    public void addUser(DTO user) {
	        String sql = "INSERT INTO users (id, password, nickname) VALUES (?, ?, ?)";

	        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
	             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
	             
	            preparedStatement.setString(1, user.getId());
	            preparedStatement.setString(2, user.getPassword());
	            preparedStatement.setString(3, user.getNickname());
	            preparedStatement.executeUpdate();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    private String getNickname() {
			// TODO Auto-generated method stub
			return null;
		}

		private String getPassword() {
			// TODO Auto-generated method stub
			return null;
		}

		private String getId() {
			// TODO Auto-generated method stub
			return null;
		}

		// Method to get a user by ID
	    public DTO getUser(String id) {
	        DTO user = null;
	        String sql = "SELECT * FROM users WHERE id = ?";

	        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
	             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
	             
	            preparedStatement.setString(1, id);
	            ResultSet resultSet = preparedStatement.executeQuery();

	            if (resultSet.next()) {
	                user = new DTO(
	                    resultSet.getString("id"),
	                    resultSet.getString("password"),
	                    resultSet.getString("nickname")
	                );
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return user;
	    }

	    // Method to update a user
	    public void updateUser(DTO user) {
	        String sql = "UPDATE users SET password = ?, nickname = ? WHERE id = ?";

	        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
	             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
	             
	            preparedStatement.setString(1, user.getPassword());
	            preparedStatement.setString(2, user.getNickname());
	            preparedStatement.setString(3, user.getId());
	            preparedStatement.executeUpdate();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    // Method to delete a user
	    public void deleteUser(String id) {
	        String sql = "DELETE FROM users WHERE id = ?";

	        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
	             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
	             
	            preparedStatement.setString(1, id);
	            preparedStatement.executeUpdate();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}
